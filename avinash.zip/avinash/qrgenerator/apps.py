from django.apps import AppConfig


class QrgeneratorConfig(AppConfig):
    name = 'qrgenerator'
